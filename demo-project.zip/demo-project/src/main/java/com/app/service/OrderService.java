package com.app.service;

import com.app.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
public class OrderService {

    List<Order> orders = new ArrayList<>();

    public void initializeOrders() {
        orders.add(new Order("Order1", "ProdId", 2.0));
    }

    @Async
    public CompletableFuture<Order> getOrderById(String orderId) {
        log.info("getting order details asynchronously - started");
        Optional<Order> order = orders.stream()
                .filter(x -> x.getOrderId().equals(orderId))
                .findFirst();
        log.info("getting order details asynchronously - ended");
        return CompletableFuture.completedFuture(order.get());
    }

}
