package com.app.dto;

import lombok.Data;

@Data
public class OrderRequest {
    private String orderId;
}
