package com.app.model;

import lombok.Data;

import java.util.List;

@Data
public class ProductList {
    private List<Product2> productList;
}
